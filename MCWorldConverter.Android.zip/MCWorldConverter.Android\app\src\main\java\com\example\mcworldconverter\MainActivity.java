package com.example.mcworldconverter;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_SELECT_DIRECTORY = 1;
    private static final int REQUEST_PERMISSIONS = 2;

    private TextView selectedDirectoryTextView;
    private RadioGroup operationTypeRadioGroup;
    private Button selectDirectoryButton;
    private Button convertButton;
    private TextView statusTextView;

    private Uri selectedDirectoryUri;
    private String selectedDirectoryPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupListeners();
        checkPermissions();
    }

    private void initViews() {
        selectedDirectoryTextView = findViewById(R.id.selected_directory_text_view);
        operationTypeRadioGroup = findViewById(R.id.operation_type_radio_group);
        selectDirectoryButton = findViewById(R.id.select_directory_button);
        convertButton = findViewById(R.id.convert_button);
        statusTextView = findViewById(R.id.status_text_view);
    }

    private void setupListeners() {
        selectDirectoryButton.setOnClickListener(v -> selectDirectory());
        convertButton.setOnClickListener(v -> startConversion());
    }

    private void checkPermissions() {
        List<String> permissions = new ArrayList<>();
        
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            // Android 11+ 需要 MANAGE_EXTERNAL_STORAGE 权限
            if (!Environment.isExternalStorageManager()) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivity(intent);
                return;
            }
        } else {
            // Android 10 及以下需要读写存储权限
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            }
            
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
            
            if (!permissions.isEmpty()) {
                ActivityCompat.requestPermissions(this, permissions.toArray(new String[0]), REQUEST_PERMISSIONS);
            }
        }
    }

    private void selectDirectory() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        startActivityForResult(Intent.createChooser(intent, "选择存档文件夹"), REQUEST_SELECT_DIRECTORY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == REQUEST_SELECT_DIRECTORY && resultCode == RESULT_OK) {
            if (data != null) {
                Uri uri = data.getData();
                if (uri != null) {
                    // 保存URI权限
                    getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    selectedDirectoryUri = uri;
                    // 从URI中提取文件夹名称
                    String folderName = getFolderNameFromUri(uri);
                    selectedDirectoryTextView.setText("已选择: " + folderName);
                    statusTextView.setText("准备就绪，可以开始转换");
                }
            }
        }
    }

    private void startConversion() {
        if (selectedDirectoryUri == null) {
            Toast.makeText(this, "请先选择存档文件夹", Toast.LENGTH_SHORT).show();
            return;
        }

        int selectedOperation = operationTypeRadioGroup.getCheckedRadioButtonId();
        boolean isDecrypt = selectedOperation == R.id.decrypt_radio_button;

        statusTextView.setText("开始转换...");
        
        // 在后台线程中执行转换操作
        new Thread(() -> {
            try {
                // 将Uri转换为实际文件路径（仅适用于本地文件系统）
                selectedDirectoryPath = getRealPathFromUri(selectedDirectoryUri);
                
                if (selectedDirectoryPath == null || !new File(selectedDirectoryPath).exists()) {
                    throw new IOException("无法访问所选文件夹");
                }
                
                if (isDecrypt) {
                    decryptSave(selectedDirectoryPath);
                } else {
                    encryptSave(selectedDirectoryPath);
                }
                
                runOnUiThread(() -> {
                    statusTextView.setText("转换完成！");
                    Toast.makeText(this, "转换成功！", Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    statusTextView.setText("转换失败: " + e.getMessage());
                    Toast.makeText(this, "转换失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void decryptSave(String directoryPath) throws IOException {
        File dir = new File(directoryPath);
        List<File> files = getAllFiles(dir);
        
        // 检查并解密文件
        for (File file : files) {
            if (XOREncrypt.checkFileIsEncrypt(file.getAbsolutePath())) {
                String tempPath = file.getAbsolutePath() + ".tmp";
                if (XOREncrypt.decryptFile(file.getAbsolutePath(), tempPath)) {
                    // 替换原文件
                    File tempFile = new File(tempPath);
                    if (tempFile.exists() && tempFile.renameTo(file)) {
                        updateStatus("解密成功: " + file.getName());
                    }
                }
            }
        }
    }

    private void encryptSave(String directoryPath) throws IOException {
        File dir = new File(directoryPath);
        List<File> files = getAllFiles(dir);
        
        // 加密特定文件类型
        for (File file : files) {
            if (file.getName().contains(".ldb") ||
                file.getName().contains("CURRENT") ||
                file.getName().contains("MANIFEST")) {
                String tempPath = file.getAbsolutePath() + ".tmp";
                if (XOREncrypt.encryptFile(file.getAbsolutePath(), tempPath)) {
                    // 替换原文件
                    File tempFile = new File(tempPath);
                    if (tempFile.exists() && tempFile.renameTo(file)) {
                        updateStatus("加密成功: " + file.getName());
                    }
                }
            }
        }
        
        // 创建网易存档标识文件
        File behaviorPackFile = new File(directoryPath, "netease_world_behavior_packs.json");
        File resourcePackFile = new File(directoryPath, "netease_world_recource_packs.json");
        
        java.nio.file.Files.write(behaviorPackFile.toPath(), "null".getBytes());
        java.nio.file.Files.write(resourcePackFile.toPath(), "null".getBytes());
    }
    
    private String getFolderNameFromUri(Uri uri) {
        String path = uri.getPath();
        if (path != null) {
            return path.substring(path.lastIndexOf('/') + 1);
        }
        return "未知文件夹";
    }
    
    private String getRealPathFromUri(Uri uri) {
        // 对于DocumentProvider返回的URI，我们需要特殊处理
        if (DocumentsContract.isDocumentUri(this, uri)) {
            if ("com.android.externalstorage.documents".equals(uri.getAuthority())) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];
                
                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }
            }
        }
        // 对于其他URI，尝试使用普通方法
        return uri.getPath();
    }

    private List<File> getAllFiles(File directory) {
        List<File> files = new ArrayList<>();
        File[] allFiles = directory.listFiles();
        
        if (allFiles != null) {
            for (File file : allFiles) {
                if (file.isDirectory()) {
                    files.addAll(getAllFiles(file));
                } else {
                    files.add(file);
                }
            }
        }
        
        return files;
    }

    private void updateStatus(String message) {
        runOnUiThread(() -> statusTextView.setText(message));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            
            if (!allGranted) {
                Toast.makeText(this, "需要存储权限才能正常工作", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }
}
