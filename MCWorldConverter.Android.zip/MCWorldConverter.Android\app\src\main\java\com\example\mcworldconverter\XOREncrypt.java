package com.example.mcworldconverter;

import java.io.*;
import java.nio.file.*;

public class XOREncrypt {
    // 网易MC中国版XOR加密密钥
    private static final byte[] KEY = {
        (byte)0x8E, (byte)0x92, (byte)0x5E, (byte)0x1A, (byte)0x5E, (byte)0x25, (byte)0x98, (byte)0x2C,
        (byte)0x75, (byte)0x9C, (byte)0x22, (byte)0x08, (byte)0x1C, (byte)0x0C, (byte)0x10, (byte)0x9A
    };

    // 检查文件是否被加密
    public static boolean checkFileIsEncrypt(String filePath) {
        try {
            byte[] header = Files.readAllBytes(Paths.get(filePath));
            if (header.length < 16) {
                return false;
            }
            
            // 检查文件头是否符合加密特征
            byte[] decryptedHeader = new byte[16];
            for (int i = 0; i < 16; i++) {
                decryptedHeader[i] = (byte)(header[i] ^ KEY[i % KEY.length]);
            }
            
            // 检查解密后的文件头是否符合预期格式
            // 对于LDB文件，通常以特定魔法数字开头
            return !isValidDecryptedHeader(decryptedHeader);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private static boolean isValidDecryptedHeader(byte[] header) {
        // 检查是否是有效的LDB文件头
        if (header.length >= 4) {
            // 简单检查，实际验证逻辑可能更复杂
            return header[0] == 0x01 || header[0] == 0x02 || header[0] == 0x03;
        }
        return false;
    }

    // 解密文件
    public static boolean decryptFile(String srcPath, String dstPath) {
        try {
            byte[] content = Files.readAllBytes(Paths.get(srcPath));
            byte[] decrypted = xorEncryptDecrypt(content);
            Files.write(Paths.get(dstPath), decrypted);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // 加密文件
    public static boolean encryptFile(String srcPath, String dstPath) {
        try {
            byte[] content = Files.readAllBytes(Paths.get(srcPath));
            byte[] encrypted = xorEncryptDecrypt(content);
            Files.write(Paths.get(dstPath), encrypted);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // XOR加密/解密核心算法
    private static byte[] xorEncryptDecrypt(byte[] data) {
        byte[] result = new byte[data.length];
        for (int i = 0; i < data.length; i++) {
            result[i] = (byte)(data[i] ^ KEY[i % KEY.length]);
        }
        return result;
    }
}
